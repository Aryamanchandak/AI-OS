"""Claude calls: generate a question, grade an answer."""
import json
import os
import re

from anthropic import Anthropic

_client = None


def client():
    global _client
    if _client is None:
        _client = Anthropic()  # reads ANTHROPIC_API_KEY from env
    return _client


def model():
    return os.getenv("CLAUDE_MODEL", "claude-opus-5-5")


def _parse_json(text):
    t = text.strip()
    t = re.sub(r"^```(?:json)?\s*|\s*```$", "", t, flags=re.MULTILINE).strip()
    start, end = t.find("{"), t.rfind("}")
    if start == -1 or end == -1:
        raise ValueError("No JSON object in model output")
    return json.loads(t[start : end + 1])


def _json_call(system, user, max_tokens):
    last_err = None
    for _ in range(2):  # one retry on malformed JSON
        msg = client().messages.create(
            model=model(),
            max_tokens=max_tokens,
            system=system,
            messages=[{"role": "user", "content": user}],
        )
        text = "".join(b.text for b in msg.content if getattr(b, "type", "") == "text")
        try:
            return _parse_json(text)
        except Exception as e:  # noqa: BLE001
            last_err = e
    raise RuntimeError(f"Claude returned unparseable JSON twice: {last_err}")


# ---------------------------------------------------------------- questions

TYPE_GUIDE = """
Question types:
- competency: behavioural question answered with a past example (STAR). E.g. a time you influenced without authority, handled conflict, failed, prioritised under pressure, used data to change a decision.
- motivational: "why this firm", "why this role", "why this industry", "where do you see yourself", "why should we hire you". Tailor to the firm/role in the candidate context if given.
- mba_essay: MBA video-essay style prompts (Kira-style): goals, why MBA / why now / why this school, a defining experience, what you'd contribute to the class, a value you hold, a quick-fire personal prompt.
- chart: show ONE chart with realistic business data and ask the candidate to interpret it and give a recommendation. The data must contain one obvious headline insight and at least one less obvious insight (mix shift, a divergence, a base effect, an outlier). Numbers must be internally consistent.
- case: a short consulting/business mini-case stated in 3-5 sentences of facts (in context_note), asking for structure + hypothesis + recommendation. May include a quick estimate.
- commercial_awareness: a business/market trend question relevant to the candidate's target industry. Avoid relying on facts that may have changed recently; frame it so a strong answer uses reasoning, not memorised news.
"""

GEN_SYSTEM = f"""You design questions for one-way (asynchronous) video interviews: the candidate sees the question, gets a short prep timer, then records an answer with no interviewer present.

Write questions the way real assessment platforms phrase them: clear, single question (or one question with at most two explicit parts), answerable in the given answer time. Match the difficulty of top-tier graduate schemes, experienced-hire screens and MBA admissions.

{TYPE_GUIDE}

Return ONLY a JSON object, no prose, with this schema:
{{
  "type": "<one of the types>",
  "question": "<exact question text shown on screen>",
  "context_note": "<scenario facts shown under the question for case/chart types, otherwise empty string>",
  "chart": null OR {{
     "kind": "bar" | "grouped_bar" | "stacked_bar" | "line",
     "title": "...",
     "x_label": "...",
     "y_label": "... (include units)",
     "categories": ["..."],
     "series": [{{"name": "...", "values": [numbers, same length as categories]}}],
     "source_note": "Illustrative data"
  }},
  "assessing": ["what the assessor is looking for, 2-4 items"],
  "strong_answer_covers": ["specific points a strong answer would make, 4-7 items; for chart questions include the exact numbers/insights"],
  "common_mistakes": ["2-4 typical weak-answer traps"]
}}
"chart" must be non-null only for type "chart". Keep categories to at most 8 and series to at most 4."""


def generate_question(qtype, context, prep_s, answer_s, recent_questions):
    recent = "\n".join(f"- {q}" for q in recent_questions) or "(none)"
    user = f"""Candidate context (what they are preparing for, written by the candidate):
<context>
{context or "(not provided - assume a competitive UK graduate / early-career analytics, finance or consulting role)"}
</context>

Question type: {qtype}
Prep time: {prep_s} seconds. Answer time: {answer_s} seconds.

Do not repeat or closely paraphrase these recent questions:
{recent}

Generate one question now."""
    q = _json_call(GEN_SYSTEM, user, 2500)
    q["type"] = q.get("type") or qtype
    if q["type"] != "chart":
        q["chart"] = None
    return q


# ---------------------------------------------------------------- grading

GRADE_SYSTEM = """You are a strict, experienced assessor for one-way video interviews at top-tier firms and MBA programmes. You score the candidate's recorded answer and coach them to improve it on the next attempt.

Calibration (be strict, do not inflate):
- 9-10: exceptional, top 5% of candidates; would clearly advance.
- 7-8: strong; would likely pass the screen.
- 5-6: average; borderline, generic or partly unstructured.
- 3-4: weak; misses the question or key elements.
- 1-2: did not meaningfully answer.
Most unrehearsed first attempts land at 4-6. Judge only what was actually said.

Content rubric by type:
- competency: clear STAR structure; specific single situation; the candidate's own actions ("I", not "we"); quantified result; reflection/learning; relevance to the competency asked.
- motivational: specific to the firm/role (concrete facts, not generic praise); linked to the candidate's own experience; shows understanding of what the role involves; forward-looking contribution.
- mba_essay: authenticity; clear goals; coherent why MBA/why now/why this school; a concrete story; memorability.
- chart: leads with the headline insight; reads the data accurately (check against the chart data provided); quantifies; spots the less obvious insight; offers drivers/hypotheses; ends with a so-what or recommendation; structured.
- case: structures the problem; states a hypothesis; prioritises; sensible numbers; clear recommendation with next steps.
- commercial_awareness: clear view; drivers and implications for the industry/firm; balanced; links to the role.
For all types also judge: directly answers the question asked; signposting/structure; conciseness; finishing within time.

Delivery: you get an annotated transcript (markers for pauses and for moments the candidate looked away from the camera lens) and computed delivery metrics. Treat the metrics as measurements from heuristic tools, not ground truth. Typical coaching ranges used here (heuristics, not validated standards): pace 130-170 words per minute; fewer than ~3 hesitation fillers ("um", "uh") per minute; first words within ~3 s of recording starting; eye contact with the lens most of the time. Pauses are not automatically bad: a short pause before a key point is fine; long or frequent mid-sentence pauses are not.

Rules:
- Every piece of criticism must cite evidence: a short quote from the transcript and/or a timestamp.
- Transcripts come from speech recognition and can contain minor errors; do not penalise obvious transcription glitches.
- Do not claim research findings or statistics. Give practical coaching.
- The model answer must be speakable within the answer time limit (assume ~150 words per minute) and should use the candidate's own experiences where they mentioned them, without inventing facts about them; where a personal fact is needed, use a bracketed placeholder like [your project].

Return ONLY a JSON object with this schema:
{
  "overall_score": <integer 1-10>,
  "verdict": "<one blunt sentence>",
  "retry_focus": "<the single most important thing to change on the next attempt>",
  "content_scores": [{"dimension": "...", "score": <1-10>, "comment": "..."}],
  "what_worked": ["..."],
  "top_fixes": [{"issue": "...", "evidence": "...", "fix": "..."}],
  "missed_points": ["points a strong answer would have made that were missing"],
  "delivery_feedback": [{"issue": "...", "evidence": "...", "fix": "..."}],
  "model_answer": "<a strong answer, as it would be spoken>"
}
Give 3-5 content_scores, at most 3 top_fixes, at most 4 delivery_feedback items."""


def grade(question, context, prep_s, answer_s, annotated_transcript, metrics):
    hidden = {
        "type": question.get("type"),
        "question": question.get("question"),
        "context_note": question.get("context_note"),
        "chart": question.get("chart"),
        "assessing": question.get("assessing"),
        "strong_answer_covers": question.get("strong_answer_covers"),
        "common_mistakes": question.get("common_mistakes"),
    }
    user = f"""Candidate context:
<context>
{context or "(not provided)"}
</context>

Question shown (with the assessor notes the candidate did NOT see):
<question>
{json.dumps(hidden, indent=2)}
</question>

Prep time: {prep_s} s. Answer time limit: {answer_s} s.

Annotated transcript (timestamps are seconds from start of recording; [pause Xs] = silence; [looks away: ...] = gaze off the camera lens; [not in frame] = face not detected):
<transcript>
{annotated_transcript or "(no speech detected)"}
</transcript>

Delivery metrics:
<metrics>
{json.dumps(metrics, indent=2)}
</metrics>

Assess the answer now."""
    return _json_call(GRADE_SYSTEM, user, 4000)
