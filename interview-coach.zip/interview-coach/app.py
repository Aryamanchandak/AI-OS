"""Local one-way interview practice app. Run: python app.py  then open http://localhost:5050"""
import json
import random
import tempfile
import threading
import time
import traceback
from pathlib import Path

from dotenv import load_dotenv
from flask import Flask, jsonify, request, send_from_directory

load_dotenv(Path(__file__).parent / ".env")

import analysis  # noqa: E402
import charts  # noqa: E402
import llm  # noqa: E402

ROOT = Path(__file__).parent
DATA = ROOT / "data"
QDIR = DATA / "questions"
ADIR = DATA / "attempts"
CONTEXT_FILE = DATA / "context.txt"
for d in (QDIR, ADIR):
    d.mkdir(parents=True, exist_ok=True)

TYPES = ["competency", "motivational", "mba_essay", "chart", "case", "commercial_awareness"]

app = Flask(__name__, static_folder="static")


def _id():
    return time.strftime("%Y%m%d-%H%M%S") + f"-{random.randint(100, 999)}"


def _err(e, code=500):
    traceback.print_exc()
    return jsonify({"error": str(e)}), code


def _public_q(qid, q):
    return {
        "id": qid,
        "type": q.get("type"),
        "question": q.get("question"),
        "context_note": q.get("context_note", ""),
        "chart_url": f"/data/questions/{qid}.png" if q.get("chart") else None,
    }


@app.get("/")
def index():
    return send_from_directory(ROOT / "static", "index.html")


@app.get("/data/<path:p>")
def data_file(p):
    return send_from_directory(DATA, p)


@app.route("/api/context", methods=["GET", "POST"])
def context():
    if request.method == "POST":
        CONTEXT_FILE.write_text(request.json.get("context", ""), encoding="utf-8")
    text = CONTEXT_FILE.read_text(encoding="utf-8") if CONTEXT_FILE.exists() else ""
    return jsonify({"context": text, "calibrated": analysis.BASELINE_PATH.exists()})


@app.post("/api/question")
def question():
    try:
        body = request.json or {}
        qtype = body.get("type", "mix")
        if qtype not in TYPES:
            qtype = random.choice(TYPES)
        prep_s, answer_s = int(body.get("prep", 30)), int(body.get("answer", 90))
        recent = []
        for f in sorted(QDIR.glob("*.json"), reverse=True)[:20]:
            try:
                recent.append(json.loads(f.read_text(encoding="utf-8"))["question"])
            except Exception:  # noqa: BLE001
                pass
        ctx = CONTEXT_FILE.read_text(encoding="utf-8") if CONTEXT_FILE.exists() else ""
        q = llm.generate_question(qtype, ctx, prep_s, answer_s, recent)
        qid = _id()
        if q.get("chart"):
            try:
                charts.render(q["chart"], QDIR / f"{qid}.png")
            except Exception as e:  # noqa: BLE001
                traceback.print_exc()
                q["chart"] = None
                q["context_note"] = (q.get("context_note") or "") + f" (chart failed to render: {e})"
        (QDIR / f"{qid}.json").write_text(json.dumps(q, indent=2), encoding="utf-8")
        return jsonify(_public_q(qid, q))
    except Exception as e:  # noqa: BLE001
        return _err(e)


def _ext(mimetype):
    return ".mp4" if "mp4" in (mimetype or "") else ".webm"


@app.post("/api/calibrate")
def calibrate():
    try:
        f = request.files["video"]
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / ("calib" + _ext(f.mimetype))
            f.save(p)
            analysis.calibrate(p)
        return jsonify({"ok": True})
    except Exception as e:  # noqa: BLE001
        return _err(e, 400)


@app.post("/api/answer")
def answer():
    try:
        qid = request.form["qid"]
        prep_s = int(request.form.get("prep", 30))
        answer_s = int(request.form.get("answer", 90))
        q = json.loads((QDIR / f"{qid}.json").read_text(encoding="utf-8"))
        aid = _id()
        folder = ADIR / aid
        folder.mkdir(parents=True)
        f = request.files["video"]
        vname = "answer" + _ext(f.mimetype)
        vpath = folder / vname
        f.save(vpath)

        a = analysis.analyse(vpath, answer_s)
        ctx = CONTEXT_FILE.read_text(encoding="utf-8") if CONTEXT_FILE.exists() else ""
        if a["metrics"].get("speech_detected"):
            fb = llm.grade(q, ctx, prep_s, answer_s, a["annotated_transcript"], a["metrics"])
        else:
            fb = {"overall_score": 1, "verdict": "No speech was detected in the recording. Check your microphone.",
                  "retry_focus": "Make sure the browser has microphone access and speak clearly.",
                  "content_scores": [], "what_worked": [], "top_fixes": [], "missed_points": [],
                  "delivery_feedback": [], "model_answer": ""}
        result = {
            "id": aid,
            "created": time.strftime("%Y-%m-%d %H:%M"),
            "question": _public_q(qid, q),
            "assessor_notes": {k: q.get(k) for k in ("assessing", "strong_answer_covers", "common_mistakes")},
            "prep": prep_s,
            "answer_limit": answer_s,
            "video_url": f"/data/attempts/{aid}/{vname}",
            **a,
            "feedback": fb,
        }
        (folder / "result.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
        return jsonify(result)
    except Exception as e:  # noqa: BLE001
        return _err(e)


@app.get("/api/history")
def history():
    items = []
    for d in sorted(ADIR.iterdir(), reverse=True):
        rp = d / "result.json"
        if not rp.exists():
            continue
        try:
            r = json.loads(rp.read_text(encoding="utf-8"))
            items.append({
                "id": r["id"], "created": r.get("created"), "type": r["question"].get("type"),
                "question": r["question"].get("question"), "score": r["feedback"].get("overall_score"),
            })
        except Exception:  # noqa: BLE001
            pass
    return jsonify(items[:100])


@app.get("/api/attempt/<aid>")
def attempt(aid):
    rp = ADIR / aid / "result.json"
    if not rp.exists():
        return jsonify({"error": "not found"}), 404
    return jsonify(json.loads(rp.read_text(encoding="utf-8")))


@app.get("/api/question/<qid>")
def get_question(qid):
    p = QDIR / f"{qid}.json"
    if not p.exists():
        return jsonify({"error": "not found"}), 404
    return jsonify(_public_q(qid, json.loads(p.read_text(encoding="utf-8"))))


if __name__ == "__main__":
    # Load Whisper in the background so the first answer isn't slow.
    threading.Thread(target=analysis.get_whisper, daemon=True).start()
    print("\n  Interview practice running at  http://localhost:5050\n")
    app.run(host="127.0.0.1", port=5050, threaded=True, debug=False)
